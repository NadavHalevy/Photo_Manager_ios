import UIKit

class AlbumCollectionReusableView: UICollectionReusableView {
  static let reuseIdentifier = "headerView"
  @IBOutlet weak var title: UILabel!
}
